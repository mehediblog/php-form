<?php
include 'db.php';

$conn = OpenCon();

//echo "Connected Successfully";



?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>niloymotors</title>
        
       
        <link rel="stylesheet" href="css/form.css" >
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" />
<style type="text/css">
 

</style>
        
    </head>
    <body >
       <div class="container bg">
            <div id="form-main">
                <div id="form-div">
                    <form action="insert.php" method="POST" enctype="" class="montform">
                        <p class="name">
                            <input name="worker_name" type="text"  placeholder="NAME" id="name"/>
                        </p>
                        <p class="email">
                            <input name="worker_email" type="text"  placeholder="INSERT YOUR EMAIL" id="email" />
                        </p>
                        <p class="workerid">
                            <input name="worker_id" type="text"   placeholder="INSERT YOUR ID" id="comment"/>
                        </p>
                        <p class="text">
                            <textarea name="worker_mes"  placeholder="Message" id="comment"class="feedback-input"></textarea>
                        </p>
                        <div class="submit">
                            <button type="submit" name="insert_product">SUBMIT</button>
                           
                        </div>
                    </form>
                   
                </div>
            </div>
      
        </div>
        
        
    </body>
</html>

<?php
  if(isset($_POST['insert_product']))
  {
      //text data variables
      
      $worker_name = $_POST['worker_name'];
      $worker_email = $_POST['worker_email'];
      $worker_id = $_POST['worker_id'];
      $worker_mes = $_POST['worker_mes'];
    
     
      
     

      if ($worker_name=='' OR $worker_email =='' OR $worker_id=='' OR $worker_mes =='') {

        echo "<script>alert('please filed the gap!') </script>";
        exit();
        
      }else{
       
       

        $insert_product = "insert into worker_information (worker_name,worker_email,worker_id,worker_mes) values ('$worker_name','$worker_email','$worker_id','$worker_mes')";
       
       $run_product = mysqli_query($conn,$insert_product);

        if($run_product){
          echo "<script>alert('insert Successfully')</script>";
        }
      
      }

      
  }



?>














