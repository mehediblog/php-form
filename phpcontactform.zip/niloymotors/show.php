<?php
include 'db.php';

$conn = OpenCon();





?>





<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    <style>
    body {
    background: #e0a2a2;position: static;
}
        .back {
    background: white;
    overflow: scroll;
    height: 500px;
    
}
        .full{
            background: white;
        }
    </style>
</head>
<body>
    
    <div class="container full">
        <div class="jumbotron">
    <h3>HERO NILOY MOTORS WORKER INFORMATION</h3> 
    <p>WHAT THE DEMANDS OF WORKER.</p> 
  </div>
  
<div class="container">
 


    
    
    <?php

 
 $result = $conn->query("SELECT * FROM worker_information");
    echo " <table class='table  table-hover' align='center'>";
  echo  "  <thead>
      <tr>
        <th>NO:</th>
        <th>NAME</th>
        <th>EMAIL</th>
        <th>id</th>
        <th>message</th>
      </tr>
    </thead>
   
    ";
 while($row = $result->fetch_array())
 {
     $id =$row['id'];
     $worker_name = $row['worker_name'];
     $worker_email = $row['worker_email'];
     $worker_id = $row['worker_id'];
     $worker_mes = $row['worker_mes'];

echo "
  
      <tr>
         <td >$id</td>
         <td>$worker_name</td>
         <td>$worker_email</td>
         <td>$worker_id</td>
         <td>$worker_mes</td>
      </tr>


";
  
 }
   echo "</table";   
 ?>
</div>
</div>
    
    
    
    
    
</body>
</html>